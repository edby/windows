{{object.copyright}}

{
    'name': u"{{ object.name }}",
    'summary': u'{{object.summary}}',
    'version': '1.0',
    'category': 'soft',
    'sequence': {{object.sequence}},
    'author': u'{{object.author}}',
    'website': u'{{object.website}}',
    'depends': {{object.depends}},
    'version': '0.1',
    'data': [
        # 'security/security.xml',
        # 'security/ir.model.access.csv',
        {{object.data}}
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'description': """
{{object.description}}
""",
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
