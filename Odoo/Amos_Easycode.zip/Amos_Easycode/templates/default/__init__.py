# -*- coding: utf-8 -*-
##############################################################################
# Odoo Connector
# QQ:35350428
# 邮件:sale@100china.cn
# 手机：13584935775
# 公司网址： www.odoo.pw  www.100china.cn
# Copyright 昆山一百计算机有限公司 2012-2016 Amos
# 日期：2014-06-18
##############################################################################

import models

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: