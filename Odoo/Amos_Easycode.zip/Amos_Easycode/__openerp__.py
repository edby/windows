# -*- coding: utf-8 -*-
# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
# Odoo Connector
# QQ:35350428
# 邮件:sale@100china.cn
# 手机：13584935775
# 作者：'odoo'
# 公司网址： www.odoo.pw  www.100china.cn
# Copyright 昆山一百计算机有限公司 2012-2016 Amos
# 日期：2014-06-18
# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
{
    'name': 'Amos odoo9.0 EasyCode',
    'summary': u'代码生成器',
    'version': '1.0',
    'category': 'base',
    'sequence': 0,
    'author': 'Amos',
    'website': 'http://www.odoo.pw',
    'depends': ['base'],
    'data': [
        # 'security/security.xml',
        # 'security/ir.model.access.csv',
        'views/ir_model_fields.xml',
        'views/base.xml',
        'views/EasyCode.xml',
        'views/amos_model.xml',

    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'description': """
Odoo8.0/9.0/10.0 代码生成器
==================================
界面设计

功能
-------------
* 快速生成
* 字典查询
""",
}



# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
