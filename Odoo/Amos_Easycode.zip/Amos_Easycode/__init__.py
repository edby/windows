# -*- coding: utf-8 -*-
##############################################################################
# OpenERP Connector
# Copyright 2013 Amos <sale@100china.cn>
##############################################################################

import EasyCode
import Alpha

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: