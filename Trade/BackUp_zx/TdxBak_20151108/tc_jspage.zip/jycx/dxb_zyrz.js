var dxb_zyrz ={};
dxb_zyrz.page = {};
dxb_zyrz.curSCode = '';
dxb_zyrz.curSwitch =0;
dxb_zyrz.gridIdList=['#cccx_grid', '#htcx_grid','#qxlx_grid'];
dxb_zyrz.page.zyzqdm = ''; 
dxb_zyrz.page.zjyt = '2'; //1.新股申购,2.用途不限
dxb_zyrz.page.zhlb = '';
dxb_zyrz.jkjemin = ''; //最小借款金额
dxb_zyrz.qxcombox = {}; //期限类型变量
dxb_zyrz.yt2mc = {	// 资金用途对应名称
	"1":"新股申购",
	"2":"可取可用"
}

var dxb_head = {"zjyt":1, "rcfbh":1, "rcfmc":1, "qxlx1":1, "rcfkjed":1}; //不会清空的项

$(function(){
	$("#tab").tabs({
		height:26,
		border:false
	});
	var tabList=["持仓查询","合同查询","期限类型"];
	jy_share.addTab('tab',tabList,0);
	$("#tab").tabs("options").onSelect=function(title,index){

		dxb_zyrz.curSwitch = index; 
		jy_grid.gridShow(dxb_zyrz.gridIdList,dxb_zyrz.curSwitch);
		getGridData(index);
	};

	//判断资金用途是否可配置
	get_zjytpz();

	//获得最小借款金额
	get_jkjemin();

	//获得各个表头的信息
	get_tabinfo();

	//获得左边内容中的融出方编号
	get_leftinfo();

	// 获得股东代码
	get_gddm();

	var resizeTimer = null;
	window.onresize = function(){
	   	resizeTimer = resizeTimer ? null : setTimeout(doResize,300);
	}
	function doResize(){
		$('#right_panel').layout('resize');
		$(dxb_zyrz.gridIdList[dxb_zyrz.curSwitch]).datagrid('resize');
	}

	// 开始的时候鼠标的焦点放在证券代码栏
	$("#zyzqdm").focus();
})

function get_zjytpz() {
	var _ix = new IXContent();
	_ix.Set('key', 'ZJYTPZ');
	Win_CallTQL('ret_zjytpz', 'gettradeccf', _ix, '');
}

function ret_zjytpz(_fromid,_funid,_flagtype,_json) {
	//ZJYTPZ=1；1表示可配置，0表示不可配置
	if(_json == 1) {
		$("#zjyt").removeAttr("disabled");
	}
}

function get_jkjemin() {
	var _ix = new IXContent();
	_ix.Set('key', 'JKJEMIN');
	Win_CallTQL('ret_jkjemin', 'gettradeccf', _ix, '');
}

function ret_jkjemin(_fromid,_funid,_flagtype,_json) {
	// ;
	dxb_zyrz.jkjemin = _json;
}

function get_gddm() {
	var _ix = new IXContent();
	_ix.Set('F113', 0);
	Win_CallTQL('ret_gddm', 'JY:1122', _ix, '');
}

function ret_gddm(_fromid,_funid,_flagtype,_json) {
	// ;
	// debugger;
	var data = FormatResult(_json, 1);
	data = filterGddm(data);
	var str = "";
	$.each(data.rows, function(index, value) {
		if(value.F281 != 1) {
			str += "<option zhlb='" + value.F125 
				+ "' gddm='" + value.F123 
				+ "' zhbz='" + value.F246
				+ "'>" +zhlb2mc[value.F125]+ value.F123 + "</option>"; 
		}
	});

	$("#gddm").html(str);
	dxb_zyrz.page.gddm = $("#gddm").find("option:selected").attr("gddm");
	dxb_zyrz.page.zhlb = $("#gddm").find("option:selected").attr("zhlb");
}

//股东代码改变时，清空后面的数据
function gddmchange(extra) {

	// debugger;

	dxb_zyrz.page.gddm = $("#gddm").find("option:selected").attr("gddm");
	dxb_zyrz.page.zhlb = $("#gddm").find("option:selected").attr("zhlb");

	// clear(dxb_zyrz.page, extra);

	// alert(JSON.stringify(dxb_zyrz.page));
	// 鼠标焦点在证券代码栏
	$("#zqdm").focus();

	// 如果证券代码长度小于6，即证券代码非法
	if(dxb_zyrz.page.zyzqdm.length < 6) {
		return;
	}

	// $("#sgjg").numberspinner('setValue', '');
	// $("#sgsl").numberspinner('setValue', '');

	// 根据zhlb填入相应的combox期限内容
	insertqxcombox(dxb_zyrz.page.zhlb, "qxlx", dxb_zyrz.qxcombox);
	dxb_zyrz.page.rcfbh = $("#qxlx").find("option:selected").attr("hybh");
	dxb_zyrz.page.rcfmc = $("#qxlx").find("option:selected").attr("hymc");
	dxb_zyrz.page.qxlx1 = $("#qxlx").find("option:selected").attr("qxlx");

	var _ix = new IXContent();
	_ix.Set('F234', '2'); //设置TDX_ID_LX
	_ix.Set('F113', dxb_zyrz.page.zjyt); //设置TDX_ID_CZBZ
	_ix.Set('F115', '1'); //设置TDX_ID_HZHGZT
	_ix.Set('F759', dxb_zyrz.page.rcfbh); //设置TDX_ID_HYBH
	_ix.Set('F140', dxb_zyrz.page.zyzqdm); //设置TDX_ID_ZQDM
	_ix.Set('F1195', dxb_zyrz.page.qxlx1); // 设置TDX_ID_HYQX
	_ix.Set('F125', dxb_zyrz.page.zhlb); //设置TDX_ID_ZHLB
	_ix.Set('F123', dxb_zyrz.page.gddm);

	Win_CallTQL('ret_zqinfo', 'JY:1886', _ix, '');
}

//--------------------------------得到左边内容中的融出方编号--------------------------------//
function get_leftinfo() {
	var _ix = new IXContent();
	_ix.Set('F234', '2');
	_ix.Set('F113', dxb_zyrz.page.zjyt);
	_ix.Set('F115', '11');

	Win_CallTQL('ret_leftinfo', 'JY:1886', _ix, '');
}

function ret_leftinfo(_fromid,_funid,_flagtype,_json) {
	// ;
	// debugger;
	var arr = JSON.parse(_json);
	if(arr[0][0] == -1) {
		// $.messager.alert("提示", fmtResinfo(arr[0][1]));
		$.messager.alert("提示", fmtResinfo(arr[0][1]));
		return;
	}

	var data = FormatResult(_json, 1);
	// alert(JSON.stringify(data));
	// debugger;

	// 组成期限类型数据
	dxb_zyrz.qxcombox = formqxcombox(data);

	// 清理原有的数据，但是不包括qxcombox的数据
	clear(dxb_zyrz.page);
	$("#qxlx").html(''); 	// 清理qxcombox中的内容
	
	// 赋值产品链接
	// alert(data.rows[0].F1249);
	$("#cpsm").attr("href", data.rows[0].F1249);
}

// 融出方编号改变处理函数
function rcfbhchange() {
	dxb_zyrz.page.rcfbh = $("#qxlx").find("option:selected").attr("hybh");
	dxb_zyrz.page.rcfmc = $("#qxlx").find("option:selected").attr("hymc");
	dxb_zyrz.page.qxlx1 = $("#qxlx").find("option:selected").attr("qxlx");

	if($("#zyzqdm").attr('value').length < 6) {
		// alert("here");
		clear(dxb_zyrz.page);

		// 这时将鼠标焦点放在证券代码上
		$("#zyzqdm").focus();
		return;
	}

	//这部分直接在原有的数据的基础上进行查询
	var _ix = new IXContent();
	_ix.Set('F234', '2'); //设置TDX_ID_LX
	_ix.Set('F113', dxb_zyrz.page.zjyt); //设置TDX_ID_CZBZ
	_ix.Set('F115', '1'); //设置TDX_ID_HZHGZT
	_ix.Set('F759', dxb_zyrz.page.rcfbh); //设置TDX_ID_HYBH
	_ix.Set('F140', dxb_zyrz.page.zyzqdm); //设置TDX_ID_ZQDM
	_ix.Set('F1195', dxb_zyrz.page.qxlx1); // 设置TDX_ID_HYQX
	_ix.Set('F125', dxb_zyrz.page.zhlb); //设置TDX_ID_ZHLB
	_ix.Set('F123', dxb_zyrz.page.gddm);

	$("#jkje").numberspinner('setValue', '');

	Win_CallTQL('ret_zqinfo', 'JY:1886', _ix, '');
}

function clear(page) {
	$.each(page, function(index, value) {
		// ;
		if(dxb_head[index] == undefined) {
			if(index == 'cpsm') {
				$("#" + index).attr("href", "");
			} else {
				$("#" + index).val("");
			}
			dxb_zyrz.page[index] = "";
		}
	});

	$("#jkje").numberspinner('setValue', '');
}

//--------------------------------得到左边内容中的融出方编号 end ----------------------------//


//-------------------------初始化 获得各个表头的信息 ----------------------------------------//
function get_tabinfo() {

	//获得期限类型表格
	var _ix = new IXContent();
	_ix.Set('F234', '2');
	_ix.Set('F113', dxb_zyrz.page.zjyt);

	//期限类型查询
	Win_CallTQL('ret_tab', 'JY:1876', _ix, '');

	//获得持仓查询表格
	var _ix = new IXContent();
	Win_CallTQL('ret_tab', 'JY:1890', _ix, '');

	//获得合同查询表格
	var _ix = new IXContent();
	_ix.Set('F234', '2');
	Win_CallTQL('ret_tab', 'JY:1872', _ix, '');
}

function ret_tab(_fromid,_funid,_flagtype,_json) {

	// ;
	var arr = JSON.parse(_json);
	if(arr[0][0] == -1) {
		// $.messager.alert("提示", fmtResinfo(arr[0][1]));
		$.messager.alert("提示", fmtResinfo(arr[0][1]));
		return;
	}

	if(_funid == 'JY:1876') {

		var arr = JSON.parse(_json);
		var clist = formatcolumnlist(arr[1], arr[2]);
		jy_grid.createGrid('qxlx_grid',clist,{rownumbers:false,border:false});
		$('#qxlx_grid').datagrid("getPanel").hide();

	} else if (_funid == 'JY:1890') {

		var arr = JSON.parse(_json);
		var clist = formatcolumnlist(arr[1], arr[2]);
		jy_grid.createGrid('cccx_grid',clist,{rownumbers:false,border:false});
		// var data = FormatResult(_json, 1);
		// jy_grid.gridUpdateData('cccx_grid', 0, {rows:data.rows,total:1});
		getGridData(dxb_zyrz.curSwitch);
		$("#cccx_grid").datagrid({
			onDblClickRow:griddbclick
		});

	} else if(_funid == 'JY:1872') {

		var arr = JSON.parse(_json);
		var clist = formatcolumnlist(arr[1], arr[2]);
		jy_grid.createGrid('htcx_grid',clist,{rownumbers:false,border:false});
		$('#htcx_grid').datagrid("getPanel").hide(); 
		
	}
}

function griddbclick(rowindex, rowdata) {
	var zqdm = rowdata['F140'];
	if(zqdm == '' || zqdm.length != 6) {
		return ;
	}

	//清空原有的数据
	clear(dxb_zyrz.page);

	$("#zyzqdm").val(zqdm);
	get_zqxx(zqdm);
}
//---------------------初始化 获得各个表头的信息 end----------------------------------------//

//-------------------------------- 获得证券信息---------------------------------------------//
function get_zqxx(zqdm) {
	// debugger;
	dxb_zyrz.page.zyzqdm = zqdm;
	getgpzhlb(zqdm);
}

// 由股票代码获得账户类别
function getgpzhlb(zqdm) {
	// ;
	var _ix = new IXContent();
	_ix.Set('F140', zqdm); //设置TDX_ID_ZQDM
	Win_CallTQL('ret_getzhlb', 'getgpcodexx', _ix, '');
}

function ret_getzhlb(_fromid,_funid,_flagtype,_json) {
	// ;
	dxb_zyrz.page.zhlb = _json.split("#")[0];

	$("#gddm option").attr("selected", false);
	$.each($("#gddm option[zhlb='" + dxb_zyrz.page.zhlb + "']"), function(index, value) {
		if($(value).attr("zhbz") == 1) {
			$(value).attr("selected", true);
			return false;
		} else {
			$("#gddm option[zhlb='" + dxb_zyrz.page.zhlb + "']").attr("selected", true);
		}
	})

	gddmchange({"zhlb":1, "gddm":1, "zqdm":1});

	// 根据zhlb填入相应的combox期限内容
	// insertqxcombox(dxb_zyrz.page.zhlb, "qxlx", dxb_zyrz.qxcombox);
	// dxb_zyrz.page.rcfbh = $("#qxlx").find("option:selected").attr("hybh");
	// dxb_zyrz.page.rcfmc = $("#qxlx").find("option:selected").attr("hymc");
	// dxb_zyrz.page.qxlx1 = $("#qxlx").find("option:selected").attr("qxlx");

	// var _ix = new IXContent();
	// _ix.Set('F234', '2'); //设置TDX_ID_LX
	// _ix.Set('F113', dxb_zyrz.page.zjyt); //设置TDX_ID_CZBZ
	// _ix.Set('F115', '1'); //设置TDX_ID_HZHGZT
	// _ix.Set('F759', dxb_zyrz.page.rcfbh); //设置TDX_ID_HYBH
	// _ix.Set('F140', dxb_zyrz.page.zyzqdm); //设置TDX_ID_ZQDM
	// _ix.Set('F1195', dxb_zyrz.page.qxlx1); // 设置TDX_ID_HYQX
	// _ix.Set('F125', dxb_zyrz.page.zhlb); //设置TDX_ID_ZHLB
	// _ix.Set('F123', dxb_zyrz.page.gddm);

	// Win_CallTQL('ret_zqinfo', 'JY:1886', _ix, '');
}

function ret_zqinfo(_fromid,_funid,_flagtype,_json) {

	// debugger;
	var arr = JSON.parse(_json);
	if(arr[0][0] == -1) {
		// alert(arr[0][1]);
		$.messager.alert("提示", fmtResinfo(arr[0][1]));
		return;
	}	

	var data = FormatResult(_json, 1);

	dxb_zyrz.page.zqmc = data.rows[0].F141 || null; //证券名称
	dxb_zyrz.page.zdkzysl = data.rows[0].F211 || 0; //最大可买，最大质押数量
	dxb_zyrz.page.zdkjje = data.rows[0].F148  || 0; //最大可借金额
	dxb_zyrz.page.cpsm = data.rows[0].F1249  || 0;
	dxb_zyrz.page.xyj = data.rows[0].F949  || 0; //协议价
	dxb_zyrz.page.dqghje = data.rows[0].F154 || 0; // 到期购回金额
	dxb_zyrz.page.zsl = data.rows[0].F1198 || 0; // 折算率
	dxb_zyrz.page.lybzbl = data.rows[0].F1186 || 0; // 原履约保障比例
	dxb_zyrz.page.yjfy = data.rows[0].F1183 || 0; // 预计费用
	dxb_zyrz.page.rzgzx = data.rows[0].F250 || 0; // 融资关注线
	dxb_zyrz.page.sjje = data.rows[0].F265 || 0; // 实借金额
	dxb_zyrz.page.rzjjx = data.rows[0].F251 || 0; // 融资警戒线
	dxb_zyrz.page.yjlx = data.rows[0].F1185 || 0; // 预计利息
	dxb_zyrz.page.rzczx = data.rows[0].F252 || 0; // 融资处置线
	dxb_zyrz.page.rzll = data.rows[0].F1184 || 0; // 融资利率
	dxb_zyrz.page.ghrq = data.rows[0].F127 || 0; // 购回日期

	// alert(dxb_zyrz.page.cpsm);

	dxb_zyrz.page.jkje = "";
	dxb_zyrz.page.zysl = "";

	// $("#jkje").numberspinner('setValue', '');
	// $("#jkje").html('');

	updatedata(dxb_zyrz.page);

	// 这时将鼠标焦点放到借款金额窗口
	$("#jkje").focus();
}

function updatedata(page) {
	$.each(page, function(index, value) {
		if(dxb_head[index] == undefined) {
			if(index == "zyzqdm") {

			} else if(index == "cpsm") {
				$("#"+index).attr("href", value);
			} else {
				$("#"+index).val(value);
			}
		}
	});
}

//-------------------------------- 获得证券信息 end---------------------------------------------//

//-------------------------------- 获取表格数据 ------------------------------------------------//
function getGridData(index) {
	// ;

	if (index == 2) {

		var _ix = new IXContent();
		_ix.Set('F234', '2');
		_ix.Set('F113', dxb_zyrz.page.zjyt);
		Win_CallTQL('ret_tabdata', 'JY:1876', _ix, '');

	} else if (index == 0) {
		var _ix = new IXContent();
		Win_CallTQL('ret_tabdata', 'JY:1890', _ix, '');

	} else if (index == 1) {

		var _ix = new IXContent();
		// _ix.Set('F113', dxb_zyrz.page.zjyt);
		_ix.Set('F234', '2');
		Win_CallTQL('ret_tabdata', 'JY:1872', _ix, '');
	}
}

function ret_tabdata(_fromid,_funid,_flagtype,_json) {
	if( _funid == 'JY:1876') {

		var data = FormatResult(_json, 1);
		jy_grid.gridUpdateData('qxlx_grid', 0, {rows:data.rows,total:1});

	} else if( _funid == 'JY:1890') {

		var data = FormatResult(_json, 1);
		jy_grid.gridUpdateData('cccx_grid', 0, {rows:data.rows,total:1});

	} else if( _funid == 'JY:1872') {

		var data = FormatResult(_json, 1);
		jy_grid.gridUpdateData('htcx_grid', 0, {rows:data.rows,total:1});

	}
}

//-------------------------------- 获取表格数据 end---------------------------------------------//

// 刷新表格信息内容
function fresh() {
	// ;
	getGridData(dxb_zyrz.curSwitch);
}

// 资金用途改变时
function zjytchange(value) {
	dxb_zyrz.page.zjyt = value;
	get_leftinfo();
	clear(dxb_zyrz.page);
	$("#zyzqdm").focus();
	getGridData(dxb_zyrz.curSwitch);
}

/*
	设置借款金额
*/
function get_jkje(value) {
	// ;
	var e = arguments.callee.caller.arguments[0] || window.event;
	if(e.keyCode == 37 || e.keyCode == 39) {
		return;
	}

	if(value == '') {
		value = 0;
	}
	if(parseFloat(value) < parseFloat(dxb_zyrz.jkjemin)) {
		$("#xd").attr("disabled", "disabled");
	} else {
		$("#jkje").numberspinner('setValue', value);
		$("#xd").removeAttr("disabled");
	}
}

function onChangeJkje(newValue,oldValue){
	// ;
	if(newValue == oldValue) {
		return;
	} else {
		dxb_zyrz.page.jkje = (newValue == '')?0:newValue;
		if(parseFloat(dxb_zyrz.page.jkje) < parseFloat(dxb_zyrz.jkjemin)) {
			$("#xd").attr("disabled", "disabled");
			return;
		} else {
			$("#xd").removeAttr("disabled");
			get_zysl();
		}
	}
}

// 在借款金额中点击enter，直接触发下单事件
function jkje_xd(value) {
	// ;
	// dxb_zyrz.page.jkje = value == ''?0:value;
	var e = arguments.callee.caller.arguments[0] || window.event;
	if(e.keyCode == 13) {
		e.keyCode = 1000000;
		dxb_zyrz.page.jkje = value == ''?0:value;
		if(parseFloat(dxb_zyrz.page.jkje) >= parseFloat(dxb_zyrz.jkjemin)) {
			onXd();
		} else {
			$.messager.alert("提示", "借款金额小于最低借款金额"+dxb_zyrz.jkjemin);
		}
	}
}

function get_zysl() {
	var _ix = new IXContent();

	_ix.Set('F115', '1'); //TDX_ID_HZHGZT
	_ix.Set('F234', '2'); //TDX_ID_LX
	_ix.Set('F113', dxb_zyrz.page.zjyt); //TDX_ID_CZBZ 送(1、新股申购 2、现金可取)
	_ix.Set('F759', dxb_zyrz.page.rcfbh); //设置TDX_ID_HYBH
	_ix.Set('F140', dxb_zyrz.page.zyzqdm); //设置TDX_ID_ZQDM
	_ix.Set('F148', dxb_zyrz.page.jkje); //送借款金额 TDX_ID_WTJE
	_ix.Set('F125', dxb_zyrz.page.zhlb); //设置TDX_ID_ZHLB
	_ix.Set('F123', dxb_zyrz.page.gddm);
	_ix.Set('F1195', dxb_zyrz.page.qxlx1);

	Win_CallTQL("ret_zysl", "JY:1886", _ix, "");
}

function ret_zysl(_fromid,_funid,_flagtype,_json) {
	// ;
	var arr = JSON.parse(_json);
	if(arr[0][0] == -1) {
		// $.messager.alert("提示",arr[0][1],"info");
		$.messager.alert("提示", fmtErrInfo(arr[0][1]));
		$("#zysl").val(0);
		return;
	}
	
	var data = FormatResult(_json, 1);
	dxb_zyrz.page.zysl = data.rows[0].F211;

	dxb_zyrz.page.zqmc = data.rows[0].F141; //证券名称
	// dxb_zyrz.page.zdkzysl = data.rows[0].F211; //最大可买，最大质押数量
	// dxb_zyrz.page.zdkjje = data.rows[0].F148; //最大可借金额
	// dxb_zyrz.page.cpsm = data.rows[0].F1249; //产品说明url
	dxb_zyrz.page.xyj = data.rows[0].F949; //协议价
	dxb_zyrz.page.dqghje = data.rows[0].F154; // 到期购回金额
	dxb_zyrz.page.zsl = data.rows[0].F1198; // 折算率
	dxb_zyrz.page.lybzbl = data.rows[0].F1186; // 原履约保障比例
	dxb_zyrz.page.yjfy = data.rows[0].F1183; // 预计费用
	dxb_zyrz.page.rzgzx = data.rows[0].F250; // 融资关注线
	dxb_zyrz.page.sjje = data.rows[0].F265; // 实借金额
	dxb_zyrz.page.rzjjx = data.rows[0].F251; // 融资警戒线
	dxb_zyrz.page.yjlx = data.rows[0].F1185; // 预计利息
	dxb_zyrz.page.rzczx = data.rows[0].F252; // 融资处置线
	dxb_zyrz.page.rzll = data.rows[0].F1184; // 融资利率

	dxb_zyrz.date = data.rows[0].F127; // 合同终止日期
	updatedata(dxb_zyrz.page);
}

// 下单处理函数
function onXd() {

	if(parseInt(dxb_zyrz.page.jkje % 100) != 0) {
		$.messager.alert("提示", "最小变动单位为100元");
		return;
	}

	if($("#zysl").val() == 0) {
		$.messager.alert("提示", "质押数量为0，不能下单。");
		return;
	}

	var s = '';
	s += '<div class="confirm_txt">';
	s += '<p>资金用途:' + dxb_zyrz.yt2mc[dxb_zyrz.page.zjyt] + '</p>';
	s += '<p>质押代码:' + dxb_zyrz.page.zyzqdm + '</p>';
	s += '<p>证券名称:' + dxb_zyrz.page.zqmc + '</p>';
	s += '<p>期限类型:' + dxb_zyrz.page.rcfmc + '</p>';
	s += '<p>借款金额:' + dxb_zyrz.page.jkje + '</p>';
	s += '<p>质押数量:' + dxb_zyrz.page.zysl + '</p>';
	s += '<p>融资利率:' + dxb_zyrz.page.rzll + '</p>';
	s += '<p>购回日期:' + dxb_zyrz.page.ghrq + '</p>';
	s += '</div>';
	$.messager.confirm('委托确认', s, function(r) {
		if (r) {
			realXd();
		}
	});
}

function realXd() {
	var _ix = new IXContent();

	_ix.Set('F115', '1'); //TDX_ID_HZHGZT
	_ix.Set('F234', '2'); //TDX_ID_LX
	_ix.Set('F113', dxb_zyrz.page.zjyt); // TDX_ID_CZBZ
	_ix.Set('F759', dxb_zyrz.page.rcfbh); //设置TDX_ID_HYBH
	_ix.Set('F1195', dxb_zyrz.page.qxlx1); //TDX_ID_HYQX
	_ix.Set('F140', dxb_zyrz.page.zyzqdm); //设置TDX_ID_ZQDM
	_ix.Set('F125', dxb_zyrz.page.zhlb); //设置TDX_ID_ZHLB
	_ix.Set('F148', dxb_zyrz.page.jkje); //TDX_ID_WTJE
	_ix.Set('F144', dxb_zyrz.page.zysl); //TDX_ID_WTSL
	_ix.Set('F127', dxb_zyrz.page.ghrq); //TDX_ID_ZZRQ
	_ix.Set('F123', dxb_zyrz.page.gddm);

	Win_CallTQL("ret_xd", "JY:1884", _ix, '');
}

function ret_xd(_fromid,_funid,_flagtype,_json) {
	if(_funid=='JY:1884'){
		try{
			var arr = JSON.parse(_json);
			if(arr[0][0] == -1) {
				// $.messager.alert("提示",arr[0][1],"info");
				$.messager.alert("提示", fmtResinfo(arr[0][1]));
				return;
			}	
			var data = FormatResult(_json, 1);
			if(data.ErrorCode == 0){
				if(data.rows != undefined){
					$.messager.alert("提示", fmtResinfo(data.rows[0].F149));
				}
				else{

				}
			}
			else{
				$.messager.alert("提示",fmtResinfo(data.ErrorInfo));
			}
		}
		catch(e){
		}
	}
}