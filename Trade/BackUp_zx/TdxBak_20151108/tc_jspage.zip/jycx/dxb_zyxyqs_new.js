var dxb_zgxyqs ={};
var count_time ={};
var timeout_id ={};
dxb_zgxyqs.urlList=[];
count_time.ywxy = 15;
count_time.fxtss= 15;
count_time.fxpg = 60;
var idList = ['ywxy','fxtss','fxpg', 'zxsqs', 'ytcnh', 'wygzs'];

$(function(){
	$.each(idList,function(i,id){
		$('#'+id+'_win').window("options").onClose=function(){
			clearTimeout(timeout_id[id]);
			$('#'+id+'ts').css('cursor','none');
			$('#'+id+'check_w').css('cursor','none');
			document.getElementById(id+'check_w').checked = false;
		};
	})

	// 判断是否答题
	// debugger;
	var _ix = new IXContent();
	_ix.Set('KEY', "F123");
	Win_CallTQL('ret_QA', 'GetGallery', _ix, '');
})

function ret_QA(_fromid,_funid,_flagtype,_json) {
	// alert(_json);
	$("#fxpgwd").removeAttr("disabled");
	$("#fxpgwd").bind('click', onReadWrapper);

	var arr = _json.split("#");
	if(arr[1] == 1) {	// 已答题
		$("#fxpgcheck").removeAttr('disabled');
		$("#fxpglabel").removeAttr('disabled');
		$("#fxpgcheck").click();
	} else {	// 未答题
		// alert(0);
		// $("#fxpgwd").removeAttr("disabled");
		// $("#fxpgwd").bind('click', onReadWrapper);
	}

	get_xxcx();
}

function onReadWrapper() {
	// 将阅读的标示位设置为0 
	var _ix = new IXContent();
	_ix.Set("F123", "4#0");
	Win_CallTQL('set_QA', 'InitGallery', _ix, '');
	
	onRead('fxpg');
}

function set_QA(_fromid,_funid,_flagtype,_json) {}

/*
	打新宝信息查询
*/
function get_xxcx(){
	var _ix = new IXContent();
	_ix.Set('F234', '1');
	_ix.Set('F115', '32');
	Win_CallTQL('ret_xxcx', 'JY:1886', _ix, '');
}

function ret_xxcx(_fromid,_funid,_flagtype,_json){
	// debugger;
	if(_funid=='JY:1886'){
		try{

			// var arr = JSON.parse(_json);
			// if(arr[0][0] == -1) {
			// 	$.messager.alert("提示", fmtResinfo(arr[0][1]));
			// 	return;
			// }
			
			var data = FormatResult(_json, 1);
			if(data.ErrorCode == 0){
				if(data.rows != undefined){
					// ;
					var urlStr= data.rows[0].F1249;
					dxb_zgxyqs.urlList = urlStr.split('@');
					$('#cpxx_url').attr('src',dxb_zgxyqs.urlList[0]);
				}
				else{
				}
			}
			else{
				// debugger;
				// $.messager.alert("提示",fmtResinfo(data.ErrorInfo));
				// var info = "<div style='width:200px;margin:5%;line-height:26px;color:red;'>" 
				// 		+ fmtResinfo(data.ErrorInfo) + "</div>";
				var index1 = data.ErrorInfo.indexOf("原因：") + 3;
				var index2 = data.ErrorInfo.indexOf("您的开户");
				var info = "<div style='width:400px;margin:5%;line-height:26px;color:red;'>" 
						 + data.ErrorInfo.substring(0, index1);
				// 没有第2个原因
				if (index2 == -1) {
					info += "<br>1. " + data.ErrorInfo.substr(index1);
				}
				// 有第2个原因，没有第一个原因
				else if (index2 <= (index1 + 2)) {
					info += "<br>1. " + data.ErrorInfo.substr(index2);
				}
				// 同时有第1,2原因
				else {
					info += "<br>1. " + data.ErrorInfo.substring(index1, index2)
						 +  "<br>2. " + data.ErrorInfo.substr(index2);
				}
				info += "</div>";
				$("body").html(info);
			}
		}
		catch(e){
		}
	}
}

function onRead(id){
	$('#'+id+'sure').attr('disabled', 'disabled');
	$('#'+id+'ts').attr('disabled', 'disabled');
	$('#'+id+'check_w').attr('disabled', 'disabled');
	count_time[id] =(id=='fxpg')?30:15;
	$('#'+id+'_win').window("open");
	if(id=='ywxy'){
		if(dxb_zgxyqs.urlList[2].indexOf("www") == 0) {
			dxb_zgxyqs.urlList[2] = "http://" + dxb_zgxyqs.urlList[2];
		}
		$('#'+id+'_url').attr('src',dxb_zgxyqs.urlList[2]);
	}
	else if(id=='fxtss'){
		if(dxb_zgxyqs.urlList[3].indexOf("www") == 0) {
			dxb_zgxyqs.urlList[3] = "http://" + dxb_zgxyqs.urlList[3];
		}
		$('#'+id+'_url').attr('src',dxb_zgxyqs.urlList[3]);	
	}	
	else if(id=='fxpg'){
		// $('#'+id+'_url').attr('src',dxb_zgxyqs.urlList[1]);
		// $('#'+id+'_url').attr('src',"dxb_fxpgcp.html");
		var _ix=new IXContent();
		_ix.Set("ID", "js.webforjs24");//操作方式
		Win_CallTQL('ret_executefeature', 'executefeature', _ix ,'');
	}
	else if(id == 'zxsqs') {
		if(dxb_zgxyqs.urlList[4].indexOf("www") == 0) {
			dxb_zgxyqs.urlList[4] = "http://" + dxb_zgxyqs.urlList[4];
		}
		$('#'+id+'_url').attr('src',dxb_zgxyqs.urlList[4]);	
	}
	else if(id == 'ytcnh') {
		if(dxb_zgxyqs.urlList[5].indexOf("www") == 0) {
			dxb_zgxyqs.urlList[5] = "http://" + dxb_zgxyqs.urlList[5];
		}
		$('#'+id+'_url').attr('src',dxb_zgxyqs.urlList[5]);	
	}
	else if(id == 'wygzs') {
		if(dxb_zgxyqs.urlList[6].indexOf("www") == 0) {
			dxb_zgxyqs.urlList[6] = "http://" + dxb_zgxyqs.urlList[6];
		}
		$('#'+id+'_url').attr('src',dxb_zgxyqs.urlList[6]);	
	}
	setTime(id);
}

function ret_executefeature() {}

function setTime(id) {
	$('#'+id+'djs').text('还需要'+count_time[id]+'秒');
	if(count_time[id]>0) {
		count_time[id]--;
		timeout_id[id]= setTimeout(function(){setTime(id)}, 1000);
	}
	else  if (count_time[id] ==0) {
		clearTimeout(timeout_id[id]);
		timeout_id[id] = null;
		$('#'+id+'ts').removeAttr('disabled');
		$('#'+id+'ts').css('cursor','pointer');
		$('#'+id+'check_w').removeAttr('disabled');
		$('#'+id+'check_w').css('cursor','pointer');
	}
}

function onWinChecked(id){
	(document.getElementById(id+'check_w').checked) ? $('#'+id+'sure').removeAttr('disabled') : $('#'+id+'sure').attr('disabled', 'disabled');
}

function onCancel(id){
	$('#'+id+'_win').window("close");
}

function onSure(id){
	$('#'+id+'_win').window("close");
	$('#'+id+'label').removeAttr('disabled');
	$('#'+id+'check').removeAttr('disabled');
	$('#'+id+'check').css('cursor','pointer');
	$('#'+id+'label').css('cursor','pointer');
	document.getElementById(id+'check').checked = true;
	// if(document.getElementById('ywxycheck').checked&&document.getElementById('fxtsscheck').checked&&document.getElementById('fxpgcheck').checked)
	// 	$('#xyqs').removeAttr('disabled');
	setXyqs();
}

function setXyqs(){
	(
		document.getElementById('ywxycheck').checked
		&& document.getElementById('fxtsscheck').checked
		&& document.getElementById('fxpgcheck').checked
		&& document.getElementById('zxsqscheck').checked
		&& document.getElementById('ytcnhcheck').checked
		&& document.getElementById('wygzscheck').checked
	) ? $('#xyqs').removeAttr('disabled') : $('#xyqs').attr('disabled','disabled');
}

function onXyqs(){
	get_qsxy();
	// get_rcf(); // 获得融出方
}

// function get_rcf() {
// 	var _ix = new IXContent();
// 	_ix.Set('F115', '11');
// 	_ix.Set('F234', '2');
// 	_ix.Set('F113', '1');
// 	Win_CallTQL('ret_rcf', 'JY:1886', _ix, '');
// }

// function ret_rcf(_fromid, _funid, _flagtype, _json) {
// 	var data = FormatResult(_json, 1);
// 	if(data.ErrorCode == 0) {
// 		if(data.rows[0] != undefined) {
// 			get_qsxy(data.rows[0].F759);
// 		}
// 	} else {
// 		$.messager.alert("提示", fmtResinfo(data.ErrorInfo));
// 	}
// }

/*
	打新宝信息查询
*/
function get_qsxy(rcf){
	var _ix = new IXContent();
	// _ix.Set('F234', '1');
	// _ix.Set('F115', '10');
	// _ix.Set('F121', User.zjzh); // 增加资金账号
	_ix.Set('F115', '32');
	// _ix.Set('F759', rcf);
	Win_CallTQL('ret_qsxy', 'JY:1884', _ix, '');
}

function ret_qsxy(_fromid,_funid,_flagtype,_json){
	var _ix = new IXContent();
	_ix.Set("F123", "0#0");
	Win_CallTQL('set_QA', 'InitGallery', _ix, '');
	
	_json = _json.replace(/\r\n/g, "<br>");
	var arr = JSON.parse(_json);
	if(arr[0][0] == -1) {
		$.messager.alert("提示", fmtResinfo(arr[0][1]));
		return;
	}

	var data = FormatResult(_json, 1);
	// alert(JSON.stringify(data));
	if(data.ErrorCode == 0){
		if(data.rows[0] != undefined){
			$.messager.alert("提示", fmtResinfo(data.rows[0].F149));
		}
	}
	else{
		$.messager.alert("提示",fmtResinfo(data.ErrorInfo));
	}
}
