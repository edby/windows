var opt = {};

$(function(){
	opt.time_1 = 0;
	opt.time_2 = 0;
	opt.time_3 = 0;
	get_Gddm();
})

/*
	获取股东代码
*/
function get_Gddm(){
	// debugger;

	// 操作标记 送 3， 返回非基金的股东账户
	var _ix = new IXContent();
	_ix.Set('F113', '3');
	Win_CallTQL('ret_Gddm', 'JY:1122', _ix, '');
}

function ret_Gddm(_fromid,_funid,_flagtype,data) {
	if (_funid == 'JY:1122') {
		var gddmStr = "";
		var data = FormatResult(data, 1);
		if (data.ErrorCode == 0){
			for (var i = 0; i < data.rows.length; i++) {
				if(data.rows[i]["F125"]=='0'){
					// opt.zqzh = data.rows[i]["F123"];
					// break;
					gddmStr += "<option value = '" + data.rows[i]["F123"] + "'>" + data.rows[i]["F123"] + "</option>";
				} 
			}

		$("#gddm").html(gddmStr);
		gddmSelChange();
			// get_cybxx();
		} 
		else{
			$.messager.alert("提示",data.ErrorInfo,"error");
		}
	}
}

function gddmSelChange() {
	opt.zqzh = $("#gddm").val();

	// 清空一些信息
	$("#cybywktzt").text("");
	$("#zdcybywqszt").text("");
	$("#cybgpscjyrq").text("");
	$("#xm").val("");
	$("#lxdh").val("");
	$("#shgx").val(1);
	$("#tybtn").attr("disabled", "disabled");

	get_cybxx();
}

/*
	客户柜台创业板信息查询
*/
function get_cybxx(){
	var cfg ={
		"funcid":"585450",
		"exchange_type":'2',
		"stock_account":opt.zqzh,
		"funcname":'ret_cybxx'
	};
	zxxyqs_share.setIX(cfg);
}

function ret_cybxx(_fromid,_funid,_flagtype,data){
	if (_funid == '5010:CITICS.585450') {
		try {
			var data = FormatResult(data, 1);
			if (data.ErrorCode == 0) {
				$('#cybywktzt').text('未开通');
				get_zdcybsdx();
				// get_zdcsjyr();
			}
			else {
				$.messager.alert("提示",data.ErrorInfo,"error");
			}
		} 
		catch (e) {
		}
	}
}

/*
	客户中登创业板适当性查询
*/
function get_zdcybsdx(){
	var cfg ={
		"funcid":"585451",
		"exchange_type":'2',
		"stock_account":opt.zqzh,
		"funcname":'ret_zdcybsdx'
	};
	zxxyqs_share.setIX(cfg);
}

function ret_zdcybsdx(_fromid,_funid,_flagtype,data){
	// debugger;
	if (_funid == '5010:CITICS.585451') {
		try {
			var data = FormatResult(data, 1);
			if (data.ErrorCode == 0) {
				opt.pstr_1 = data.rows[0].position_str;
				get_zdcybcx();
			}
			else {
				$.messager.alert("提示",data.ErrorInfo,"error");
			}
		} 
		catch (e) {
		}
	}
}

/*
	客户中登创业板查询结果查询
*/
function get_zdcybcx(){
	var cfg ={
		"funcid":"585452",
		"exchange_type":'2',
		"stock_account":opt.zqzh,
		"position_str":opt.pstr_1,
		"funcname":'ret_zdcybcx'
	};
	zxxyqs_share.setIX(cfg);
}

function ret_zdcybcx(_fromid,_funid,_flagtype,data){
	if (_funid == '5010:CITICS.585452') {
		try {
			var data = FormatResult(data, 1);
			if (data.ErrorCode == 0) {
				$('#zdcybywqszt').text('状态正常');
				opt.csdc_sign_kind = data.rows[0].csdc_sign_kind;
				opt.csdc_sign_date = data.rows[0].csdc_sign_date;
				get_zdcsjyr();
			}
			else {
				if(data.ErrorInfo.indexOf('-680000')==1){
					if(opt.time_1>=10){
						if(!zxxyqs_share.checkNull(opt.timeout_1)){
							clearTimeout(opt.timeout_1);
						}
						opt.time_1 = 0;
						$.messager.alert("提示","查询超时！","error");
						$('#zdcybywqszt').text('查询超时！');
					}
					else{
						$('#zdcybywqszt').text('正在查询中...');
						opt.timeout_1= setTimeout(time_zdcybcx, 1000);
					}
				}
				else if(data.ErrorInfo.indexOf('586640')==1){
					// $('#zdcybywqszt').text("您尚未开通过创业板业务，需要到营业部临柜办理。");
					// $.messager.alert("提示",data.ErrorInfo,"error");

					// 修改  如果该账户没有开通创业板业务，那么需要查询该用户的其他深A账户，看看是否有已开通的创业板业务
					// 获得该账户下其他的深A账户
					getOtherAccount();
				}
				else{
					var info_str = data.ErrorInfo.split(')')[1];
					$('#zdcybywqszt').text(info_str);
					// $('#zdcybywqszt').text("查询失败！");
					$.messager.alert("提示",data.ErrorInfo,"error");
				}
			}
		} 
		catch (e) {
		}
	}
}

// 获得该账户下其他的深A账户
function getOtherAccount() {
	var cfg = {
		"funcid":"585463",
		"exchange_type":"2",
		"stock_account":opt.zqzh,
		"funcname":"ret_accountptr"
	};
	zxxyqs_share.setIX(cfg);
}

function ret_accountptr(_fromid, _funid, _flagtype, data) {
	//debugger;
	if (_funid == '5010:CITICS.585463') {
		try {
			var data = FormatResult(data, 1);
			if (data.ErrorCode == 0) {
				opt.time_4 = 0;
				opt.pstr_4 = data.rows[0].position_str;
				get_account();
				
			}
			else {
				$.messager.alert("提示",data.ErrorInfo,"error");
			}
		} 
		catch (e) {
		}
	}
}

function get_account() {
	var cfg = {
		"funcid":"585464",
		"exchange_type":"2",
		"stock_account":opt.zqzh,
		"position_str": opt.pstr_4,
		"funcname":"ret_account"
	};
	zxxyqs_share.setIX(cfg);
}

function ret_account(_fromid, _funid, _flagtype, data) {
	//debugger;
	if (_funid == '5010:CITICS.585464') {
		try {
			var data = FormatResult(data, 1);
			if (data.ErrorCode == 0) {
				// 这里需要有结构
				// opt.users = { "股东账号": ["对应定位串", 对应查询结果, "权限开通日期", "签约日期", "开通类别", "股东账号"], ... }
				// 对应查询结果  0 - 未正确获得结果  1 - 得到结果，并且开通权限  2 - 得到结果，未开通权限
				// debugger;
				try {
					
					// 该账户没有其他的账户，这里需要直接提醒 未开通
					if (data.rows == undefined || data.rows.length == 0) {
						$('#zdcybywqszt').text("您尚未开通过创业板业务，需要到营业部临柜办理。");
						return;
					};

					opt.users = {};
					for(var i = 0; i < data.rows.length; i++) {
						var rowdata = data.rows[i];
						opt.users[rowdata["csdc_stock_account"]] = ["", 0, "", "", "", rowdata["csdc_stock_account"]];
					}
					
					opt.count = data.rows.length;
					// 获得其他账户对应的定位串
					getPtrOthers();
				} catch(e) { }
			}
			else {
				if (data.ErrorInfo.indexOf('-680000') == 1) {
					if (opt.time_4 >= 10) {
						$.messager.alert("提示","查询超时！","error");
						$('#zdcybywqszt').text('查询超时！');
					} else {
						opt.time_4 ++;
						setTimeout(get_account, 1000);
					}
				} else {
					$.messager.alert("提示",data.ErrorInfo,"error");	
				}
			}
		} 
		catch (e) {
		}
	}
}

function getPtrOthers() {
	// debugger;
	opt.reccount = 0;
	$.each(opt.users, function(key, arrdata) {
		zxxyqs_share.WinCallTQLWrapper("585451", {
			"exchange_type":'2',
			"stock_account":opt.zqzh,
			"csdc_stock_account": key
		}, ret_PtrOthers);
	})
}

function ret_PtrOthers(data, csdcstockaccount) {
	try {
		var data = FormatResult(data, 1);
		if (data.ErrorCode == 0) {
			opt.users[csdcstockaccount][0] = data.rows[0].position_str;
			opt.reccount ++ ;
			if (opt.reccount == opt.count) {
				opt.times = 0; // 当前同步发送的次数
				getZdcybOthers();
			};
		}
		else {
			$.messager.alert("提示",data.ErrorInfo,"error");
		}
	} 
	catch (e) {
	}
}


function getZdcybOthers() {
	// debugger;
	opt.times ++;
	opt.count = 0; // 记录并行发送的个数
	opt.reccount = 0; // 记录并行放回的请求个数
	if (opt.times <= 10) {
		$('#zdcybywqszt').text('正在查询中...');
		$.each(opt.users, function(key, arrdata) {
			if (arrdata[1] == 0) {
				opt.count ++;
				zxxyqs_share.WinCallTQLWrapper("585452", {
					"exchange_type":"2",
					"stock_account":opt.zqzh,
					"csdc_stock_account":key,
					"position_str":arrdata[0]
				}, retZdcybOthers);
			};
		});		
	} else {
		$.messager.alert("提示","查询超时！","error");
		$('#zdcybywqszt').text('查询超时！');
	}
}

function retZdcybOthers(data, csdcstockaccount) {

	try {
		opt.reccount ++;
		var data = FormatResult(data, 1);
		if (data.ErrorCode == 0) {
			// $('#zdcybywqszt').text('状态正常');
			opt.users[csdcstockaccount][1] = 1;
			opt.users[csdcstockaccount][2] = data.rows[0]["right_open_date"];
			opt.users[csdcstockaccount][3] = data.rows[0]["csdc_sign_date"];
			opt.users[csdcstockaccount][4] = data.rows[0]["csdc_sign_kind"];
		} else {
			if(data.ErrorInfo.indexOf('-680000')==1){
				
			}
			else if(data.ErrorInfo.indexOf('586640')==1){
				opt.users[csdcstockaccount][1] = 2;
			}
			else{
				var info_str = data.ErrorInfo.split(')')[1];
				$('#zdcybywqszt').text(info_str);
				$.messager.alert("提示",data.ErrorInfo,"error");
				opt.reccount --; // 这是为了防止这个请求报错后，还会接着发请求
			}
		}
		if (opt.reccount == opt.count) {
			var minktdate = "";
			var signdate = "";
			var signkind = "";
			var cstockaccount = "";
			var flag = 0;
			$.each(opt.users, function(key, arrdata) {
				if (arrdata[1] == 0) { // 查询不通， 1s后再查
					flag = 1;
					setTimeout(getZdcybOthers, 1000);
					return false;
				};
				if (arrdata[1] == 1) { // 结果正确返回，且有开通信息
					// debugger;
					if (minktdate == "") {
						minktdate = arrdata[2];
						signdate = arrdata[3];
						signkind = arrdata[4];
						cstockaccount = arrdata[5];
					} else if (parseInt(minktdate) > parseInt(arrdata[2])) {
						minktdate = arrdata[2];
						signdate = arrdata[3];
						signkind = arrdata[4];
						cstockaccount = arrdata[5];
					};
				};
			});
			if (flag == 0) {

				if (minktdate == "" || minktdate == undefined) {
					$('#zdcybywqszt').text("您尚未开通过创业板业务，需要到营业部临柜办理。");
				} else {	
					$('#zdcybywqszt').text('状态正常');
					opt.csdc_sign_kind = signkind;
					opt.csdc_sign_date = signdate;
					opt.csdc_stock_account = cstockaccount;
					get_zdcsjyr();
				}
			};
		};
	} 
	catch (e) {
	}

}


/*
	创业板股票首次交易日
*/
function get_zdcsjyr(){
	var cfg ={
		"funcid":"585453",
		"exchange_type":'2',
		"stock_account":opt.zqzh,
		"funcname":'ret_zdcsjyr'
	};
	zxxyqs_share.setIX(cfg);
}

function ret_zdcsjyr(_fromid,_funid,_flagtype,data){
	if (_funid == '5010:CITICS.585453') {
		try {
			var data = FormatResult(data, 1);
			if (data.ErrorCode == 0) {
				opt.pstr_2 = data.rows[0].position_str;
				get_zdcsjyrcx();
			}
			else {
				$.messager.alert("提示",data.ErrorInfo,"error");
			}
		} 
		catch (e) {
		}
	}
}

/*
	客户中登首次交易日期查询结果查询
*/
function get_zdcsjyrcx(){
	var cfg ={
		"funcid":"585454",
		"exchange_type":'2',
		"stock_account":opt.zqzh,
		"position_str":opt.pstr_2,
		"funcname":'ret_zdcsjyrcx'
	};
	zxxyqs_share.setIX(cfg);
}

function ret_zdcsjyrcx(_fromid,_funid,_flagtype,data){
	if (_funid == '5010:CITICS.585454') {
		try {
			var data = FormatResult(data, 1);
			if (data.ErrorCode == 0) {
				opt.csdc_first_trade_date = data.rows[0].csdc_first_trade_date;
				$('#cybgpscjyrq').text(opt.csdc_first_trade_date);
				// $('#tybtn').attr('disabled', 'disabled');
				$('#tybtn').removeAttr('disabled');
				// get_zdcybxxdj();
			}
			else {
				if(data.ErrorInfo.indexOf('-680000')==1){
					if(opt.time_2>=10){
						if(!zxxyqs_share.checkNull(opt.timeout_2)){
							clearTimeout(opt.timeout_2);
						}
						opt.time_2 = 0;
						$.messager.alert("提示","查询超时！","error");
						$('#cybgpscjyrq').text('查询超时！');
					}
					else{
						$('#cybgpscjyrq').text('正在查询中...');
						opt.timeout_2= setTimeout(time_zdcsjyrcx, 1000);
					}
				}
				else if(data.ErrorInfo.indexOf('586640')==1){
					$('#zdcybywqszt').text("您尚未开通过创业板业务，需要到营业部临柜办理。");
					$.messager.alert("提示",data.ErrorInfo,"error");
				}
				else{
					var info_str = data.ErrorInfo.split(')')[1];
					$('#cybgpscjyrq').text(info_str);
					// $('#cybgpscjyrq').text("查询失败！");
					$.messager.alert("提示",data.ErrorInfo,"error");
				}
			}
		} 
		catch (e) {
		}
	}
}

/*
	客户中登创业板信息登记
*/
function get_zdcybxxdj(){
	var cfg ={
		"funcid":"585455",
		"exchange_type":'2',
		"stock_account":opt.zqzh,
		"csdc_first_trade_date":opt.csdc_first_trade_date,
		"csdc_stock_account": opt.csdc_stock_account || "",
		"csdc_sign_kind":opt.csdc_sign_kind,
		"csdc_sign_date":opt.csdc_sign_date,
		"funcname":'ret_zdcybxxdj'
	};
	zxxyqs_share.setIX(cfg);
}

function ret_zdcybxxdj(_fromid,_funid,_flagtype,data){
	if (_funid == '5010:CITICS.585455') {
		try {
			var data = FormatResult(data, 1);
			if (data.ErrorCode == 0) {
				opt.pstr_3 = data.rows[0].position_str;
				get_zdcybxxdjcx();
			}
			else {
				$.messager.alert("提示",data.ErrorInfo,"error");
			}
		} 
		catch (e) {
		}
	}
}

/*
	客户中登创业板信息登记结果查询
*/
function get_zdcybxxdjcx(){
	var cfg ={
		"funcid":"585456",
		"exchange_type":'2',
		"stock_account":opt.zqzh,
		"position_str":opt.pstr_3,
		"csdc_first_trade_date":opt.csdc_first_trade_date,
		"csdc_stock_account": opt.csdc_stock_account || "",
		"funcname":'ret_zdcybxxdjcx'
	};
	zxxyqs_share.setIX(cfg);
}

function ret_zdcybxxdjcx(_fromid,_funid,_flagtype,data){
	if (_funid == '5010:CITICS.585456') {
		try {
			var data = FormatResult(data, 1);
			if (data.ErrorCode == 0) {
				// $('#tybtn').removeAttr('disabled');
				get_khgtcybxxdj();
			}
			else {
				if(data.ErrorInfo.indexOf('-680000')==1){
					if(opt.time_3>=10){
						if(!zxxyqs_share.checkNull(opt.timeout_3)){
							clearTimeout(opt.timeout_3);
						}
						opt.time_3 = 0;
						$.messager.alert("提示","查询超时！","error");
					}
					else{
						opt.timeout_3= setTimeout(time_zdcybxxdjcx, 1000);
					}
				}
				else{
					$.messager.alert("提示",data.ErrorInfo,"error");
				}
			}
		} 
		catch (e) {
		}
	}
}

/*
	客户柜台创业板信息登记
*/
function get_khgtcybxxdj(){
	var cfg ={
		"funcid":"585457",
		"exchange_type":'2',
		"stock_account":opt.zqzh,
		"sec_relation_name":opt.sec_relation_name,
		"sec_relation_phone":opt.sec_relation_phone,
		"socialral_type":opt.socialral_type,
		"csdc_sign_kind":opt.csdc_sign_kind,
		"csdc_sign_date":opt.csdc_sign_date,
		"csdc_stock_account": opt.csdc_stock_account || "",
		"funcname":'ret_khgtcybxxdj'
	};
	zxxyqs_share.setIX(cfg);
}

function ret_khgtcybxxdj(_fromid,_funid,_flagtype,data){
	if (_funid == '5010:CITICS.585457') {
		try {
			var data = FormatResult(data, 1);
			if (data.ErrorCode == 0) {
				var kt_str = data.rows[0].right_open_date;
				$.messager.alert("提示","权限开通成功，开通日期："+kt_str+'。',"info");
				$('#tybtn').attr('disabled', 'disabled');
			}
			else {
				$.messager.alert("提示",data.ErrorInfo,"error");
			}
		} 
		catch (e) {
		}
	}
}


function time_zdcybcx(){
	if(!zxxyqs_share.checkNull(opt.timeout_1)){
		clearTimeout(opt.timeout_1);
	}
	opt.time_1+=1;
	get_zdcybcx();
}

function time_zdcsjyrcx(){
	if(!zxxyqs_share.checkNull(opt.timeout_2)){
		clearTimeout(opt.timeout_2);
	}
	opt.time_2+=1;
	get_zdcsjyrcx();
}

function time_zdcybxxdjcx(){
	if(!zxxyqs_share.checkNull(opt.timeout_3)){
		clearTimeout(opt.timeout_3);
	}
	opt.time_3+=1;
	get_zdcybxxdjcx();
}

function onLjkt(){
	opt.sec_relation_name = $('#xm').val();
	opt.sec_relation_phone = $('#lxdh').val();
	opt.socialral_type = $('#shgx').val();
	if(zxxyqs_share.checkNull(opt.sec_relation_name)){
		$.messager.alert("提示","姓名不能为空，请输入！","info");
	}
	else{
		if(zxxyqs_share.checkNull(opt.sec_relation_phone)){
			$.messager.alert("提示","联系电话不能为空，请输入！","info");
		}
		else{
			// get_khgtcybxxdj();
			get_zdcybxxdj();
		}
	}
}

function onKeyPress(node,e,len){
    var k = window.event ? e.keyCode:e.which;
    if (((k >= 48) && (k <= 57)) ||k==8|| k==0){    
        if($(node).attr('value').length==len){
            var txt=getSelectedText($(node)[0]);
            if(txt.length==0){
                if(window.event) window.event.returnValue = false; 
                else e.preventDefault();
                return;
            }
        }
    }
    else{
        if(window.event) window.event.returnValue = false; 
        else e.preventDefault();
    }
}

function getSelectedText(inputDom){ 
    if (document.selection) 
     {
        return document.selection.createRange().text;
    } 
    else { 
        return inputDom.value.substring(inputDom.selectionStart, 
                inputDom.selectionEnd); 
    } 
}	
