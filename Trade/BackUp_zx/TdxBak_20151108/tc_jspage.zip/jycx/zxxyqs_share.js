var zxxyqs_share = {};
/*
*设置IX协议
*@param cfg为{},其中funcid和funcname2个key必须填入
*/
zxxyqs_share.setIX=function(cfg){
	var _ix = new IXContent();
	_ix.Set('op_branch_no', User.yyb);//操作分支机构
	_ix.Set('op_entrust_way', User.wtfs);//委托方式
	_ix.Set('@MAC',User.minfo);//站点地址
	_ix.Set('branch_no',User.yyb);//分支机构
	_ix.Set('client_id',User.khh);//客户号
	_ix.Set('fund_account',User.zjzh);//资金账户
	_ix.Set('password','##PWD##');//密码
	_ix.Set('password_type','2');//密码类型
	_ix.Set('sysnode_id',User.sysnode_id[User.zjzh] );
	_ix.Set('asset_prop',User.asset_prop[User.zjzh] );
	_ix.Set('user_token',User.user_token);//用户口令
	_ix.Set('request_num','1000');
	$.each(cfg,function(key,val){
		if(key=="funcid"||key=="funcname"){}
		else{
			_ix.Set(key, val);
		}
	})
	Win_CallTQL(cfg.funcname, '5010:CITICS.'+cfg.funcid, _ix, '');
}

zxxyqs_share.WinCallTQLWrapper = function(funcid, ixs, callback) {
	//debugger;
	var _ix = new IXContent();
	_ix.Set('op_branch_no', User.yyb);//操作分支机构
	_ix.Set('op_entrust_way', User.wtfs);//委托方式
	_ix.Set('@MAC',User.minfo);//站点地址
	_ix.Set('branch_no',User.yyb);//分支机构
	_ix.Set('client_id',User.khh);//客户号
	_ix.Set('fund_account',User.zjzh);//资金账户
	_ix.Set('password','##PWD##');//密码
	_ix.Set('password_type','2');//密码类型
	_ix.Set('sysnode_id',User.sysnode_id[User.zjzh] );
	_ix.Set('asset_prop',User.asset_prop[User.zjzh] );
	_ix.Set('user_token',User.user_token);//用户口令
	_ix.Set('request_num','1000');
	$.each(ixs, function(key, value) {
		_ix.Set(key, value);
	});
	var funcname = "ret_func" + parseInt(Math.random() * 10000);
	window[funcname] = function(_fromid, _funid, _flagtype, _json) {
		callback(_json, ixs["csdc_stock_account"]);
		window[funcname] = null;
	}
	Win_CallTQL(funcname, '5010:CITICS.'+funcid, _ix, '');
}

zxxyqs_share.checkNull=function(obj){
    return (obj==undefined||obj==null||obj=='')?true:false;
}

/*
    翻译数据字典
*/
zxxyqs_share.transDict=function(dict,key){
    if(zxxyqs_share.checkNull(dict)&&zxxyqs_share.checkNull(key)) return '';
    return (zxxyqs_share.checkNull(dict[key])?'':dict[key]);
}

/*
    客户账户状态
*/
zxxyqs_share.zhzt ={
	'0':'正常',
	'1':'冻结',
	'2':'挂失',
	'3':'销户',
	'4':'未确定',
	'5':'休假',
	'C':'中登休眠',
	'D':'风险处置',
	'E':'中登不合格',
	'F':'系统锁定',
	'G':'内部休眠',
	'H':'纯资金休眠',
	'J':'内部不合格'
}

zxxyqs_share.formatZhzt = function(val){
	return zxxyqs_share.transDict(zxxyqs_share.zhzt,val);
}


/*获取登录信息的sysnode_id*/
function get_uidxml(){
	var _ix = new IXContent();
	_ix.Set('keyid ', 'F1299');
	Win_CallTQL('ret_uidxml', 'getuidxml', _ix  ,'');
}

function ret_uidxml(_fromid,_funid,_flagtype,data) {
	if(_funid == 'getuidxml'){
		if(data!=""){
			try{
				var temp_list =data.split('@');
				temp_list.shift(0);
				User.user_token = temp_list.shift(0);
				temp_list.pop();
				User.sysnode_id ={};
				User.asset_prop ={};
				$.each(temp_list, function(index, val) {
					var sysnode_list = val.split(',');
					User.sysnode_id[sysnode_list[0]] = sysnode_list[1];
					User.asset_prop[sysnode_list[0]] = sysnode_list[2];
				});
			}
			catch(e){
				alert("获取登录信息的sysnode_id！\r\n"+data);
			}

			testXyzh(); // 信用账户限制
		}
	}
}

/**
 *原来打新宝的信用账户判断在tlib/page/page.js文件中实现，但是该文件是公共文件
 *其他的功能有可能没有信用账户的限制问题，所以现在将该部分的判断，提出到jy_share.js文件中
 */
function testXyzh() {
    // 获取账号UID下面否一个字段
    var _ix = new IXContent();
    _ix.Set("keyid", "F281");
    Win_CallTQL('ret_GetSpecialFlag', 'GetSpecialFlag', _ix, '');
}

function ret_GetSpecialFlag(_fromid,_funid,_flagtype,data) {

    // alert(data);
    if(data == 1) { // 账号为信用账号，不能做打新宝的操作
        window.location.href = "error.html";
        return;
    }  
}

$(function(){
	get_uidxml();
})
